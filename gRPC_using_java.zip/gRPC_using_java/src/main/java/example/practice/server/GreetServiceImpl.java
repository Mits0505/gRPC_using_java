package example.practice.server;

import com.proto.greet.*;
import com.proto.greet.GreetServiceGrpc.GreetServiceImplBase;
import io.grpc.stub.StreamObserver;

public class GreetServiceImpl extends GreetServiceImplBase {
    @Override
    public void greet(GreetRequest request, StreamObserver<GreetResponse> responseObserver) {

        // Extract the fields that we need.
       Greet greeting = request.getGreeting();
       String name = greeting.getFirstName();

       // Create the response.
       String result = "Hello "+ name;
       GreetResponse greetResponse = GreetResponse.newBuilder()
               .setResult(result).build();

       // Send the response.
       responseObserver.onNext(greetResponse);

       // Complete the RPC call.
       responseObserver.onCompleted();
    }

    @Override
    public void greetManyTimes(GreetManyTimesRequest request, StreamObserver<GreetManyTimesResponse> responseObserver) {
        // Extract the fields that we need.
        Greet greeting = request.getGreeting();
        String name = greeting.getFirstName();
        try{
            for(int i=0 ; i<10; i++) {
                String result = "Hello " + name + " ,response number: " + i;
                GreetManyTimesResponse greetManyTimesResponse = GreetManyTimesResponse.newBuilder()
                        .setResult(result)
                        .build();
                responseObserver.onNext(greetManyTimesResponse);
                Thread.sleep(1000L);
            }
        }catch (InterruptedException e){
            e.printStackTrace();
        }finally {
            responseObserver.onCompleted();
        }
    }

    @Override
    public StreamObserver<LongGreetRequest> longGreet(StreamObserver<LongGreetResponse> responseObserver) {
        StreamObserver<LongGreetRequest> streamObserver = new StreamObserver<LongGreetRequest>() {
            String result = "";
            @Override
            public void onNext(LongGreetRequest value) {
            // Client sends a message.
                result+="Hello "+value.getGreeting().getFirstName()+"! ";
            }

            @Override
            public void onError(Throwable t) {
            // Client sends an error.
            }

            @Override
            public void onCompleted() {
            // Client is done.
            // This is when we want to return a response (ResponseObserver.)
                responseObserver.onNext(LongGreetResponse.newBuilder()
                                                         .setResult(result)
                                                         .build());
                responseObserver.onCompleted();
            }
        };
        return streamObserver;
    }
}
