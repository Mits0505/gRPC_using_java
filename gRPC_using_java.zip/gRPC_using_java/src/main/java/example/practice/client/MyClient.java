package example.practice.client;

import com.proto.dummy.DummyServiceGrpc;
import com.proto.greet.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class MyClient {
    public static void main(String[] args) {
        System.out.println("Hello I am a gRPC Client");

        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost",50051)
                .usePlaintext()
                .build();

        System.out.println("Creating a stub");
        //DummyServiceGrpc.DummyServiceBlockingStub syncStub = DummyServiceGrpc.newBlockingStub(channel);
        //DummyServiceGrpc.DummyServiceFutureStub asyncStub = DummyServiceGrpc.newFutureStub(channel);

        // Created a greet service client (blocking - synchronous)
        GreetServiceGrpc.GreetServiceBlockingStub syncGreetStub = GreetServiceGrpc.newBlockingStub(channel);

       /* // Unary.
        // Created a protocol buffer for GreetRequest.
        GreetRequest greetRequest = GreetRequest.newBuilder()
                .setGreeting(Greet.newBuilder()
                        .setFirstName("Mitali")
                        .setLastName("Aggarwal")
                        .build())
                .build();

        // Call the rpc and get back a GreetResponse (protocol buffers)
        GreetResponse greetResponse = syncGreetStub.greet(greetRequest);

        System.out.println(greetResponse.getResult());*/

       // Server Streaming.
       // We prepare the request.
        GreetManyTimesRequest greetManyTimesRequest = GreetManyTimesRequest.newBuilder().setGreeting(
                                                                                       Greet.newBuilder()
                                                                                            .setFirstName("Lokesh"))
                                                                                            .build();

        // We streams the response in a blocking manner.
        syncGreetStub.greetManyTimes(greetManyTimesRequest)
                     .forEachRemaining(GreetManyTimesResponse -> {
                         System.out.println(GreetManyTimesResponse.getResult());
                     }); ;

        System.out.println("Shutting down channel");
        channel.shutdown();
    }
}
